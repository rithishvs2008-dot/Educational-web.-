# SkillPath AI

**AI Skill Gap Detector & Personalized Learning Roadmap** — EdTech hackathon project.

> Know your gaps. Own your future.

Students often know the job they want but not the skills it needs, or where to start. SkillPath AI checks a student's skills, shows exactly which ones are missing for their dream career, and builds a personal week-by-week learning roadmap.

## Features

| Step | What it does |
| --- | --- |
| 1. Career goal | Pick one of 6 roles (AI/ML Engineer, Data Analyst, Full-Stack Developer, Cloud Engineer, Cybersecurity Analyst, UI/UX Designer). Each role lists the 6 skills it needs. |
| 2. Skill check | A 12-question quiz (2 per skill). The student can also paste their resume, and each of the 6 skills found in it adds a bonus. |
| 3. Skill gap report | Radar chart, each skill marked Strong / Close / Gap, overall readiness %, and an AI recommendation. |
| 4. Roadmap | Milestones built from the gaps, in learning order, sized to the student's hours per week. Each milestone has 3 topics and 1 project, with links to free videos. |
| 5. Progress | Readiness ring, milestone tracker, readiness over time, skill map (start vs now), study streak and hours completed. |

There is also an **AI coach** chat on the roadmap screen that knows the student's goal, skill levels and plan.

## How the scoring works

- **Skill level** = 85 × (correct answers ÷ 2), plus 15 if the skill appears in the resume (max 100)
- **Match** = your level ÷ the level the job needs (max 100%)
- **Readiness** = average Match across the 6 skills
- **Status**: 80%+ = Strong, 50–79% = Close, under 50% = Gap

## How the roadmap is built

1. Skills are taken in the order the job builds on them (for example Python → Statistics → SQL → Machine Learning → Deep Learning → MLOps).
2. Each **Gap** skill becomes one milestone: 3 learning topics + 1 project.
3. Each **Close** skill becomes a short "refresh" task inside the next milestone.
4. Hours for a skill = gap × 0.3 (at least 6 hours). Weeks = hours ÷ the student's hours per week.
5. Ticking off a task raises that skill's level, so readiness updates live.

## Run it

It is one file with no build step and no install.

- **On your computer:** download `index.html` and open it in Chrome, Edge or Firefox.
- **On GitHub Pages:** push this repo, then go to *Settings → Pages → Deploy from branch → main / root*. Your app will be live at `https://<username>.github.io/<repo-name>/`.

Progress is saved in the browser (localStorage), so each student keeps their own data on their own device.

**Demo tip:** click **"Load demo student (Priya)"** on the Home screen to jump straight to a full example (42% job-ready, 4 milestones over 12 weeks). On the Progress screen, **"Fast-forward 6 weeks"** shows what progress looks like later on.

## About the AI

The AI recommendation and the AI coach use Claude when the page is opened inside Claude. Anywhere else (a local file or GitHub Pages) they fall back to built-in rule-based tips, so every other feature works the same.

To use live AI outside Claude, add a small backend (for example FastAPI) that calls an LLM API with your own API key, and change the `getAiTip()` and `askCoach()` functions to call your backend instead. Never put an API key inside `index.html`, because anyone can read it.

## Code structure

Everything is in `index.html`. The script is split into numbered sections:

1. Icons and small helpers
2. Data: skills, quiz questions, learning topics, careers
3. State: saved in localStorage
4. Scoring
5. Roadmap builder
6. AI (Claude, with a rule-based fallback)
7. Chart helpers: radar, ring, line (plain SVG)
8. Screens: Home, Career Goal, Assessment, Skill Gap, Roadmap, Progress
9. Rendering and click handling

**Tech:** HTML, CSS and plain JavaScript. No frameworks, no libraries.

## Team

[Team Name] · [Member 1], [Member 2], [Member 3] · [Hackathon Name], EdTech track
